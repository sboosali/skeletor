import qualified Program.Skeletor.Haskell.Main as Program
import           Prelude
main :: IO ()
main = Program.main