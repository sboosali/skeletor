{-# LANGUAGE OverloadedStrings #-}

{-# LANGUAGE BinaryLiterals    #-}

--------------------------------------------------
--------------------------------------------------

{-| 

-}

module Skeletor.Core.Directory.Values where

--------------------------------------------------
--------------------------------------------------

import Skeletor.Core.Directory.Types

--------------------------------------------------
--------------------------------------------------

import qualified "unordered-containers" Data.HashMap.Lazy as HashMap
import           "unordered-containers" Data.HashMap.Lazy (HashMap)

--------------------------------------------------

import qualified "filepath" System.FilePath as FilePath

--------------------------------------------------

import qualified "text"       Data.Text    as TS
import qualified "text"       Data.Text.IO as TS

--import qualified "text"       Data.Text.Lazy.IO as TL

--------------------------------------------------

import qualified "bytestring" Data.ByteString as BS
--import qualified "bytestring" Data.ByteString.Lazy as BL

--------------------------------------------------

--import qualified "base" System.IO as IO

--------------------------------------------------

import Prelude_location

--------------------------------------------------
--------------------------------------------------

{-|

@
≡ ''
@

-}

--------------------------------------------------
--------------------------------------------------

{-|

@
≡ ''
@

-}

Directory :: Directory a
Directory = Directory



--------------------------------------------------
--------------------------------------------------
{- Notes / Old Code


-}
--------------------------------------------------
