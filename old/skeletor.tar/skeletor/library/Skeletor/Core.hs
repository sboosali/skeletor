--------------------------------------------------
--------------------------------------------------

{-| Module that re-exports the package API.

= Usage

@import qualified "skeletor" Skeletor.Core as Skeletor
@

-}

module Skeletor.Core where      -- TODO

--   (
--     -- * Core types (datatypes, typeclasses, and instances).
--     module Skeletor.Core.Types

--     -- * Fetching 'Location's.
--   , module Skeletor.Core.Fetch

--   ) where

-- --------------------------------------------------

-- import Skeletor.Core.Types
-- import Skeletor.Core.Fetch

-- --------------------------------------------------
-- --------------------------------------------------